﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;

namespace CalcProj
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string userinput = "";
        string function = "";
        //bool calon = false;
        
        
        public MainWindow()
        {
            InitializeComponent();
            calcdisplay.Text = "";
            btn0.IsEnabled = false;
            btn1.IsEnabled = false;
            btn2.IsEnabled = false;
            btn3.IsEnabled = false;
            btn4.IsEnabled = false;
            btn5.IsEnabled = false;
            btn6.IsEnabled = false;
            btn7.IsEnabled = false;
            btn8.IsEnabled = false;
            btn9.IsEnabled = false;
            btnclear.IsEnabled = false;
            btnadd.IsEnabled = false;
            btnsub.IsEnabled = false;
            btnmult.IsEnabled = false;
            btndiv.IsEnabled = false;
            btnequal.IsEnabled = false;
            btnoff.IsEnabled = false;

        }
        
        CalculatorProj.Calculator calculator = new CalculatorProj.Calculator();

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "0";
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "1";
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "2";
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "3";
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "4";
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "5";
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "6";
        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "7";
        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "8";
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            calcdisplay.Text += "9";
        }

        private void btnadd_Click(object sender, RoutedEventArgs e)
        {
            function = "+";
            calculator.input_1 = Convert.ToDouble(calcdisplay.Text);

        }

        private void btnsub_Click(object sender, RoutedEventArgs e)
        {
            function = "-";
            calculator.input_1 = Convert.ToInt32(calcdisplay.Text);

        }

        private void btnmult_Click(object sender, RoutedEventArgs e)
        {
            function = "*";
            calculator.input_1 = Convert.ToInt32(calcdisplay.Text);

        }

        private void btndiv_Click(object sender, RoutedEventArgs e)
        {
            function = "/";
            calculator.input_1 = Convert.ToDouble(calcdisplay.Text);
          
        }

        private void btnequal_Click(object sender, RoutedEventArgs e)
        {
            calculator.input_2 = Convert.ToDouble(calcdisplay.Text);

            if(function == "+")
            {
                calcdisplay.Text = Convert.ToString(calculator.Addition());

            }
            else if(function == "-")
            {
                calcdisplay.Text = Convert.ToString(calculator.Subtraction());
            }
            else if (function == "*")
            {
                calcdisplay.Text = Convert.ToString(calculator.Multiplication());
            }
            else if (function == "/")
            {
                calcdisplay.Text = Convert.ToString(calculator.Division());
            }

        }

        private void btnclear_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "0";        
            calculator.input_1 = 0;
            calculator.input_2 = 0;

        }

        private void btnoff_Click(object sender, RoutedEventArgs e)
        {
            calcdisplay.Text = "";
            btn0.IsEnabled = false;
            btn1.IsEnabled = false;
            btn2.IsEnabled = false;
            btn3.IsEnabled = false;
            btn4.IsEnabled = false;
            btn5.IsEnabled = false;
            btn6.IsEnabled = false;
            btn7.IsEnabled = false;
            btn8.IsEnabled = false;
            btn9.IsEnabled = false;
            btnclear.IsEnabled = false;
            btnadd.IsEnabled = false;
            btnsub.IsEnabled = false;
            btnmult.IsEnabled = false;
            btndiv.IsEnabled = false;
            btnequal.IsEnabled = false;
            btnoff.IsEnabled = false;
            btnon.IsEnabled = true;
 
        }

        private void btnon_Click(object sender, RoutedEventArgs e)
        {
            //calon = true;
            calcdisplay.Text = "";
            btn0.IsEnabled = true;
            btn1.IsEnabled = true;
            btn2.IsEnabled = true;
            btn3.IsEnabled = true;
            btn4.IsEnabled = true;
            btn5.IsEnabled = true;
            btn6.IsEnabled = true;
            btn7.IsEnabled = true;
            btn8.IsEnabled = true;
            btn9.IsEnabled = true;
            btnclear.IsEnabled = true;
            btnadd.IsEnabled = true;
            btnsub.IsEnabled = true;
            btnmult.IsEnabled = true;
            btndiv.IsEnabled = true;
            btnequal.IsEnabled = true;
            btnoff.IsEnabled=true;
            btnon.IsEnabled = false;

        }
    }
}
