﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorProj
{
    class Calculator
    {
        public double input_1 { get; set; }
        public double input_2 { get; set; }
        public string action { get; set; }

        

        public Calculator()
        {
            input_1 = 0;
            input_2 = 0.0;
            action = "";
        
        
        }

        public Calculator(double ip_1, double ip_2, string operation)
        {
            input_1 = ip_1;
            input_2 = ip_2;
            action = operation;
        }

        public double Addition()
        {
            double result = Convert.ToDouble(input_1 + input_2); 
            return result;
        }

        public double Subtraction()
        {
            return input_1 - input_2;
        }
        
        public double Multiplication()
        {
            return input_1 * input_2;
        }
        
        public double Division()
        {
            return input_1 / input_2;
        }


    }
}