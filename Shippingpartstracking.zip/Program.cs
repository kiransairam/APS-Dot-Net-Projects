﻿using System.Drawing;
using System.Security.Cryptography.X509Certificates;

namespace shippartstracker
{
    public class shippartstracker
    {
        public static void Main(string[] args)
        {
            int loop1 = 0;
            int loop2 = 0;
            
            var suppliers = new[]
            {
                new { SN = 1, SName = "Smith", Status = 20, City = "London"},
                new { SN = 2, SName = "Jones", Status = 10, City = "Paris"},
                new { SN = 3, SName = "Blake", Status = 30, City = "Paris"},
                new { SN = 4, SName = "Clark", Status = 20, City = "London"},
                new { SN = 5, SName = "Adams", Status = 30, City = "Athens"}

            };

            var parts = new[]
            {
                new {PN = 1, PName = "Nut", Color = "Red", Weight = 12, City = "London"},
                new {PN = 2, PName = "Bolt", Color = "Green", Weight = 17, City = "Paris"},
                new {PN = 3, PName = "Screw", Color = "Blue", Weight = 17, City = "Rome"},
                new {PN = 4, PName = "Screw", Color = "Red", Weight = 14, City = "London"},
                new {PN = 5, PName = "Cam", Color = "Blue", Weight = 12, City = "Paris"},
                new {PN = 6, PName = "Cog", Color = "Red", Weight = 19, City = "London"}

            };

            var shipments = new[] 
            {
                new {SN = 1, PN = 1, Qty = 300},
                new {SN = 1, PN = 2, Qty = 200},
                new {SN = 1, PN = 3, Qty = 400},
                new {SN = 1, PN = 4, Qty = 200},
                new {SN = 1, PN = 5, Qty = 100},
                new {SN = 1, PN = 6, Qty = 100},
                new {SN = 2, PN = 1, Qty = 300},
                new {SN = 2, PN = 2, Qty = 400},
                new {SN = 3, PN = 2, Qty = 200},
                new {SN = 4, PN = 2, Qty = 200},
                new {SN = 4, PN = 4, Qty = 300},
                new {SN = 4, PN = 5, Qty = 400}
            };

            Console.WriteLine("Suppliers Data");
            Console.WriteLine($"{"SN",-10}" + $"{"SName",-10}" + $"{"Status",-10}" + $"{"City"}");
            foreach (var supplier in suppliers)
            {
                Console.WriteLine($"{supplier.SN, -10}" + $"{supplier.SName,-10}" + $"{supplier.Status,-10}" + $"{supplier.City}");
            }

            Console.WriteLine("\n");

            Console.WriteLine("Parts Data");
            Console.WriteLine($"{"PN",-10}" + $"{"PName", -10}" + $"{"Color", -10}"  + $"{"Weight",-10}" + $"{"City"}");
            foreach (var part in parts)
            {
                Console.WriteLine($"{part.PN, -10}" +$"{part.PName,  -10}" + $"{part.Color, -10}" + $"{part.Weight, -10}" + $"{part.City, -10}");
            }

            Console.WriteLine("\n");

            Console.WriteLine("Shipments Data");
            Console.WriteLine($"{"SN",-10}" + $"{"PN",-10}" + $"{"Qty"}");
            foreach (var shipment in shipments)
            {
                Console.WriteLine($"{shipment.SN, -10}" + $"{shipment.PN,-10}" + $"{shipment.Qty}");
            }


            //Prompting user for a color input


            var color = (from part in parts
                         select part.Color).Distinct().ToArray();



            while (loop1 == 0)
            {
                Console.WriteLine("\n");
                Console.Write("Enter Color to query cities with that color parts: ");
                string inputcolor = Console.ReadLine();

                bool found = false;
                foreach (string elements in color)
                {
                    if (inputcolor.ToLower() == elements.ToLower())
                    {

                        var citycolor = (from p in parts
                                         where p.Color.ToLower() == inputcolor.ToLower()
                                         select p.City).Distinct();
                        Console.WriteLine($"Cities which has " + inputcolor + $" color parts are ");
                        foreach (string city in citycolor)
                        {
                            Console.WriteLine(city);

                        }
                        found = true;
                        break;

                    }
                }
                if (!found)
                    {
                        Console.WriteLine("No parts found with that color!!");
                        

                    }



                Console.WriteLine("\n");
                Console.WriteLine("Do you want to query Cities for another color?");
                Console.WriteLine(" Press y for Yes or any other key for No: ");
                string input = Console.ReadLine().ToLower();

                if(input != "y")
                {
                    loop1 = 1;
                }

            }

            Console.WriteLine("\n");

            /*
            IEnumerable<string> suppliernames =
                suppliers.OrderBy(supp => supp.SName).Select(name => name.SName);
            foreach (string suppliername in suppliernames)
            {
                Console.WriteLine(suppliername);
            }
            */

            Console.WriteLine("\n");

            var suppliername = from s in suppliers
                               orderby s.SName
                               select s.SName;
            Console.WriteLine("Suppliers in Suppliers data are ");
            foreach (string supname in suppliername)
            {
                Console.WriteLine(supname);
            }


            var snum = (from suppl in suppliers
                         select suppl.SN).Distinct().ToArray();
            while (loop2 == 0)
            {
                Console.WriteLine("\n");
                Console.WriteLine("Enter the Supplier number to find total orders for that suplier: ");
                int supnumber = Convert.ToInt32(Console.ReadLine());

                bool found = false;
                foreach (int elements in snum)
                {
                    if (supnumber == elements)
                    {

                        var orders = from s in shipments
                                     join p in parts
                                     on s.PN equals p.PN
                                     where s.SN == supnumber
                                     select new { p.PName, s.Qty };
                        Console.WriteLine("\n");
                        Console.WriteLine($"{"PName",-8}" + $"{"Qty"}");
                        foreach (var order in orders)
                        {
                            Console.WriteLine($"{order.PName, -8}" + $"{order.Qty}");
                        }
                        found = true;
                        break;

                    }
                }
                if (!found)
                {
                    Console.WriteLine("No Suppliers found with that Number!!");

                }

                Console.WriteLine("\n");
                Console.WriteLine("Do you want to query another supplier to get orders?");
                Console.WriteLine(" Press y for Yes or any other key for No: ");
                string input = Console.ReadLine().ToLower();

                if (input != "y")
                {
                    loop2 = 1;
                }

            }


        }

    }

}