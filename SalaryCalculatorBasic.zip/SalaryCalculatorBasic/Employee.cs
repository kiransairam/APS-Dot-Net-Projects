﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalaryCalculatorBasic
{
    public class Employee
    {
        public Employee(string firstname, string lastname, int age, double hrswrkd, double hrlypay)
        {
            firstName = firstname;
            lastName = lastname;
            empage = age;
            hrsWrkd = hrswrkd;
            hrlyPay = hrlypay;
        }
        public string firstName { get; set; }
        public string lastName { get; set; } 
        public int empage { get; set; }
        public double hrsWrkd { get; set; }
        public double  hrlyPay{ get; set; }
        



        

        public double calculateNetSalary(double hrsWrkd, double hrlyPay)
        {
            //double netSalary = hrsWrkd * hrlyPay;
            //return netSalary;
            double grosssalary = 0, overtime = 0;
            if(hrsWrkd <= 40)
            {
                grosssalary = hrsWrkd * hrlyPay;

            }
            else
            {
                grosssalary = 40 * hrlyPay;
                overtime = (hrsWrkd -40) * (hrlyPay*1.5);
                grosssalary = grosssalary + overtime;
            }
            return grosssalary;

        }
    }


}
