﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalaryCalculatorBasic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtsal_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnclc_Click(object sender, RoutedEventArgs e)
        {
            string firstName = txtfstnme.Text;
            string lastName = txtlstnme.Text;
            int Age = Convert.ToInt32(txtage.Text);
            double hrsWrkd = Convert.ToDouble(txthrswkd.Text);
            double hrlyPay = Convert.ToDouble(txthrlrte.Text);
            

            Employee employee = new Employee(firstName, lastName, Age, hrsWrkd, hrlyPay);
            double Salary = employee.calculateNetSalary(hrsWrkd, hrlyPay);
            txtsal.Text = "The salary of " +employee.firstName +" "+ employee.lastName +" for a hourly rate of " +employee.hrlyPay + " and for " +employee.hrsWrkd+" worked hours is "+  Salary.ToString();


        }
    }
}
