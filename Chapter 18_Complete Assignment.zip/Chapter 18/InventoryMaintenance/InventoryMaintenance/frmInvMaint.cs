﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryMaintenance
{
    public partial class frmInvMaint : Form
    {
        public frmInvMaint()
        {
            InitializeComponent();
        }

        private List<InvItem> invItems = null;

        private void frmInvMaint_Load(object sender, EventArgs e)
        {
            invItems = InvItemDB.GetItems();
            LoadComboBox();
            FillItemListBox();
        }

        private void LoadComboBox()
        {
            cboFilterBy.DataSource = new string[] {
                "All", "Under $10", "$10 to $50", "Over $50"
            };
        }

        private void FillItemListBox()
        { 
            lstItems.Items.Clear();
            
            string filter = cboFilterBy.SelectedValue.ToString();
            IEnumerable<InvItem> filteredItems = null;

            // add items to the filteredItems collection based on FilterBy value

            switch (filter)
            {
                case "Under $10":
                    filteredItems = invItems.Where(item => item.Price < 10).OrderBy(item => item.Description);
                    break;
                case "$10 to $50":
                    filteredItems = invItems.Where(item => item.Price >= 10 && item.Price <= 50).OrderBy(item => item.Description);
                    break;
                case "Over $50":
                    filteredItems = invItems.Where(item => item.Price > 50).OrderBy(item => item.Description);
                    break;
                default: // "All" filter
                    filteredItems = invItems.OrderBy(item => item.Description);
                    break;
            }

            // change code to loop the filteredItems collection
            foreach (InvItem item in filteredItems)
            {
                lstItems.Items.Add(item.DisplayText);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmNewItem newItemForm = new frmNewItem();
            InvItem invItem = newItemForm.GetNewItem();
            if (invItem != null)
            {
                invItems.Add(invItem);
                InvItemDB.SaveItems(invItems);
                FillItemListBox();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if an item is selected
            if (lstItems.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select an item to delete.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Get the display text of the selected item
            string selectedItemDisplayText = lstItems.SelectedItems[0].ToString();

            // Find the item to delete using LINQ
            InvItem itemToDelete = invItems.FirstOrDefault(item => item.DisplayText == selectedItemDisplayText);

            // Confirm the delete operation
            DialogResult result = MessageBox.Show($"Are you sure you want to delete {selectedItemDisplayText}?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                invItems.Remove(itemToDelete);
                FillItemListBox();
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboFilterBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillItemListBox();
        }

    }
}
