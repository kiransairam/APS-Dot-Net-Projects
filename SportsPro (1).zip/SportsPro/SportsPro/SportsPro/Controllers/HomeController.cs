﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using SportsPro.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace SportsPro.Controllers
{
    public class HomeController : Controller
    {
        private SportsProContext context { get; set; }

        public HomeController (SportsProContext ctx)
        {
            context = ctx;
        }


        public IActionResult Index()
        {
            var products = context.Products.OrderBy(m => m.Name).ToList();
            var technicians = context.Technicians.OrderBy(m => m.Name).ToList();
            return View();

        }


        public async Task<IActionResult> ProductList()
        {
            return View(await context.Products.ToListAsync());
        }


        //public IActionResult Index1()
        //{
        //   var technicians = context.Technicians.OrderBy(m => m.Name).ToList();
        //   return View(technicians);

        //}


        public async Task<IActionResult> TechnicianList()
        {
            return View(await context.Technicians.ToListAsync());
        }

 

        public IActionResult About()
        {
            return View();
        }
    }
}